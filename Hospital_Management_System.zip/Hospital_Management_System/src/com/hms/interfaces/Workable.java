package com.hms.interfaces;
public interface Workable {
    void work();
    String getRole();
    void attendMeeting();
    void generateReport();
}

